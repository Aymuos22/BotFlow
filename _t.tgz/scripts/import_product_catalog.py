#!/usr/bin/env python3
"""
Bulk-import a product catalog JSON file into the DB and auto-index
each product into Weaviate so the RAG pipeline can search them.

JSON format expected:
    {
      "products": [
        {
          "product_id": "SKR-001",   <- used as sku
          "category": "...",
          "name": "...",
          "description": "..."
        },
        ...
      ]
    }

Usage:
    python scripts/import_product_catalog.py \
        --file data/skinrange_catalog.json \
        --company-id 33eaf707-06f1-4e30-93d8-d8da71afaa92

Options:
    --skip-existing   Skip products whose SKU already exists (default: update them)
    --dry-run         Print what would be done without writing anything
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path
from uuid import UUID

_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from app.core.config import settings  # noqa: E402
from app.core.database import AsyncSessionLocal, engine  # noqa: E402
from app.integrations.weaviate.client import WeaviateClient  # noqa: E402
from app.repositories.company_config_repository import CompanyConfigRepository  # noqa: E402
from app.repositories.product_event_repository import ProductEventRepository  # noqa: E402
from app.repositories.product_repository import ProductRepository  # noqa: E402
from app.schemas.product import ProductCreate, ProductUpdate  # noqa: E402
from app.services.product_service import ProductService  # noqa: E402

logger = logging.getLogger("import_product_catalog")


async def run(
    catalog_path: Path,
    company_id: UUID,
    skip_existing: bool,
    dry_run: bool,
) -> None:
    data = json.loads(catalog_path.read_text(encoding="utf-8"))
    products_raw = data.get("products", [])
    brand = data.get("brand", "")
    logger.info(
        "Catalog: %s  brand=%r  products=%d  company=%s",
        catalog_path.name,
        brand,
        len(products_raw),
        company_id,
    )

    if dry_run:
        logger.info("[DRY RUN] Would import %d products.", len(products_raw))
        for p in products_raw:
            logger.info("  %s — %s (%s)", p.get("product_id"), p.get("name"), p.get("category"))
        return

    weaviate = WeaviateClient(
        url=settings.weaviate_url,
        api_key=settings.weaviate_api_key,
        timeout=settings.weaviate_timeout_seconds,
    )

    created = updated = skipped = failed = 0

    try:
        async with AsyncSessionLocal() as db:
            svc = ProductService(
                product_repo=ProductRepository(db),
                event_repo=ProductEventRepository(db),
                config_repo=CompanyConfigRepository(db),
                weaviate_client=weaviate,
            )

            for raw in products_raw:
                sku = raw.get("product_id") or None
                name = (raw.get("name") or "").strip()
                category = (raw.get("category") or "").strip() or None
                description = (raw.get("description") or "").strip() or None

                if not name:
                    logger.warning("Skipping entry with no name: %s", raw)
                    skipped += 1
                    continue

                existing = None
                if sku:
                    existing = await svc._products.get_by_sku(company_id, sku)

                if existing:
                    if skip_existing:
                        logger.info("  SKIP  %s — %s", sku, name)
                        skipped += 1
                        continue
                    # Update
                    try:
                        await svc.update_product(
                            existing.id,
                            company_id,
                            ProductUpdate(
                                name=name,
                                category=category,
                                description=description,
                            ),
                        )
                        logger.info("  UPDATE %s — %s  (indexed=%s)", sku, name,
                                    existing.weaviate_indexed)
                        updated += 1
                    except Exception as exc:
                        logger.error("  ERROR updating %s: %s", sku, exc)
                        failed += 1
                else:
                    # Create (auto-indexes into Weaviate)
                    try:
                        product = await svc.create_product(
                            company_id,
                            ProductCreate(
                                name=name,
                                sku=sku,
                                category=category,
                                description=description,
                                is_active=True,
                            ),
                        )
                        status = "indexed" if product.weaviate_indexed else "NOT indexed (reindex later)"
                        logger.info("  CREATE %s — %s  [%s]", sku, name, status)
                        created += 1
                    except Exception as exc:
                        logger.error("  ERROR creating %s (%s): %s", sku, name, exc)
                        failed += 1

    finally:
        await weaviate.aclose()
        await engine.dispose()

    logger.info(
        "\nDone — created=%d  updated=%d  skipped=%d  failed=%d",
        created, updated, skipped, failed,
    )


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s  %(message)s",
    )
    p = argparse.ArgumentParser(description="Bulk-import product catalog JSON → DB + Weaviate")
    p.add_argument("--file", required=True, help="Path to catalog JSON file")
    p.add_argument("--company-id", required=True, help="Target company UUID")
    p.add_argument(
        "--skip-existing",
        action="store_true",
        help="Skip products whose SKU already exists (default: update them)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print plan without writing anything",
    )
    args = p.parse_args()
    asyncio.run(
        run(
            catalog_path=Path(args.file),
            company_id=UUID(args.company_id),
            skip_existing=args.skip_existing,
            dry_run=args.dry_run,
        )
    )


if __name__ == "__main__":
    main()
