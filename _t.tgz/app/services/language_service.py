"""
Language detection and normalization service.

Approach
--------
Rule-based detection without any ML dependency – suitable for Phase 2.
Accuracy is good for clearly Hindi or clearly English text.  Hinglish
detection is intentionally broad (few false negatives over false positives)
since the cost of misidentification is minor (slightly different LLM instruction).

Devanagari Unicode block: U+0900 – U+097F
Hinglish markers: common Hindi words written in Roman script.
"""
from typing import Any, List, Optional

# Common Hindi function words and filler words written in Roman script
_HINGLISH_MARKERS = frozenset([
    # Basic verbs / forms
    "hai", "hain", "hoon", "hu", "hun", "tha", "thi", "the",
    "hota", "hoti", "hote", "hoga", "hogi", "hoge",
    "kar", "karo", "karna", "karta", "karti", "karte",
    "kiya", "kiye", "karti", "karunga", "karungi",

    # Connectors
    "aur", "ya", "lekin", "par", "kyunki", "toh", "to", "phir",
    "jab", "tab", "agar", "magar",

    # Negation
    "nahi", "nhi", "na", "mat",

    # Question words
    "kya", "kaun", "kyun", "kyu", "kab", "kahan", "kidhar", "kaise",

    # Pronouns
    "main", "mai", "mein", "me", "hum", "ham", "mera", "meri", "mere",
    "tera", "teri", "tere", "tum", "aap", "tu",
    "unka", "unki", "unke", "unhe", "unko",
    "isko", "isse", "iska", "iski", "iske",
    "usko", "usse", "uska", "uski", "uske",

    # Postpositions
    "ka", "ki", "ke", "ko", "se", "me", "mein", "par", "pe", "tak", "ke liye", "liye",

    # Common adverbs / modifiers
    "bhi", "sirf", "bas", "bahut", "bohot", "bahot",
    "thoda", "zyada", "jada", "kam", "abhi", "ab",
    "yaha", "yahan", "waha", "wahan",

    # Common adjectives
    "accha", "acha", "achha", "theek", "sahi", "galat",
    "bura", "badhiya", "mast", "solid", "bekar",

    # Commands / casual speech
    "chal", "chalo", "ruk", "ruko", "sun", "suno", "dekh", "dekho",
    "bolo", "bata", "batao", "samajh", "samjha", "samjho",

    # Requests / politeness
    "please", "pls", "plz", "kripya", "zara", "thoda",
    "bhai", "bhaiya", "bhayya", "yaar", "dost", "bhaii",

    # Fillers / conversational
    "haan", "han", "ha", "hmm", "hmmm", "arey", "arre",
    "achha", "acha", "oh", "oye", "acha",

    # Time / frequency
    "roz", "kal", "aaj", "parso", "kabhi", "hamesha",

    # Common Hinglish slang
    "scene", "setting", "jugaad", "timepass", "bakchodi",
    "faltu", "jhakkas", "pataka", "item",

    # Agreement / disagreement
    "haan", "hanji", "bilkul", "sahi", "theek",
    "nahi", "nah", "nope",

    # Respect / suffix
    "ji"
])

# Markers that are too ambiguous in English text; they create false positives.
# Example: "to" and "me" are valid Hinglish tokens but appear frequently in
# normal English questions ("how to...", "send me...").
_AMBIGUOUS_MARKERS = frozenset([
    "to",
    "me",
    "no",
    "oh",
    "the",
])

# Minimum fraction of text characters that must be Devanagari to call it Hindi
_DEVANAGARI_THRESHOLD = 0.25

# Minimum number of Hinglish marker words to classify as Hinglish
_HINGLISH_MIN_MARKERS = 2

# Minimum fraction of words that must be Hinglish markers
_HINGLISH_MARKER_FRACTION = 0.15


def detect_language(text: str) -> str:
    """
    Classify *text* as ``english``, ``hindi``, or ``hinglish``.

    Priority:
      1. If ≥ 25 % of characters are Devanagari → ``hindi``
      2. If ≥ 2 marker words or ≥ 15 % of words are Hinglish markers → ``hinglish``
      3. Otherwise → ``english``

    Args:
        text: Raw user message text.

    Returns:
        One of ``"english"``, ``"hindi"``, ``"hinglish"``.
    """
    if not text or not text.strip():
        return "english"

    # Check Devanagari
    devanagari_count = sum(1 for ch in text if "\u0900" <= ch <= "\u097F")
    if devanagari_count / max(len(text), 1) >= _DEVANAGARI_THRESHOLD:
        return "hindi"

    # Check Hinglish markers
    words = text.lower().split()
    if not words:
        return "english"

    marker_count = sum(
        1
        for w in words
        if (token := w.strip("?,!.;:'\"")) in _HINGLISH_MARKERS
        and token not in _AMBIGUOUS_MARKERS
    )
    if marker_count >= _HINGLISH_MIN_MARKERS or (
        marker_count / len(words) >= _HINGLISH_MARKER_FRACTION
    ):
        return "hinglish"

    return "english"


def normalize_query(text: str, language: str) -> str:
    """
    Normalize a search query for Weaviate retrieval.

    - English  : strip leading/trailing whitespace, collapse internal spaces.
    - Hinglish : lowercase + collapse spaces (makes BM25 more consistent).
    - Hindi    : strip whitespace, preserve Devanagari casing (unchanged).

    No transliteration or stemming is performed in Phase 2.

    Args:
        text:     Original user query.
        language: Detected language (``english``, ``hindi``, ``hinglish``).

    Returns:
        Normalized query string.
    """
    text = text.strip()
    if language in ("english",):
        return " ".join(text.split())
    elif language == "hinglish":
        return " ".join(text.lower().split())
    else:  # hindi
        return " ".join(text.split())


def is_strong_language_signal(text: str, detected: str) -> bool:
    """
    True when *text* clearly signals which language the user is using.

    Short Latin-only replies (e.g. "ok", "thanks") are treated as weak so we
    can keep replying in the last language they used in this conversation.
    """
    if not text or not text.strip():
        return False
    if detected in ("hindi", "hinglish"):
        return True
    # english (or anything else): require enough substance to switch/stick
    stripped = text.strip()
    words = stripped.split()
    if len(stripped) >= 36:
        return True
    if len(words) >= 5:
        return True
    return False


def resolve_reply_language(
    current_text: str,
    conversation_last_language: Optional[str],
    company_supported_languages: List[str],
    default_language: str,
) -> str:
    """
    Pick the language for the bot reply.

    Uses the current message when it is a strong language signal; otherwise
    falls back to *conversation_last_language* (last decisive user language).
    """
    detected = detect_language(current_text)
    if is_strong_language_signal(current_text, detected):
        return choose_output_language(
            detected_language=detected,
            company_supported_languages=company_supported_languages,
            default_language=default_language,
        )
    if conversation_last_language:
        return choose_output_language(
            detected_language=conversation_last_language,
            company_supported_languages=company_supported_languages,
            default_language=default_language,
        )
    return choose_output_language(
        detected_language=detected,
        company_supported_languages=company_supported_languages,
        default_language=default_language,
    )


def last_decisive_user_language_from_history(
    history: Optional[List[Any]],
) -> Optional[str]:
    """
    Scan portal *history* (prior turns) for the last user message with a
    strong language signal. Used for stateless portal chat stickiness.
    """
    if not history:
        return None
    last_strong: Optional[str] = None
    for turn in history:
        role = getattr(turn, "role", None)
        if role != "user":
            continue
        content = getattr(turn, "content", "") or ""
        d = detect_language(content)
        if is_strong_language_signal(content, d):
            last_strong = d
    return last_strong


def choose_output_language(
    detected_language: Optional[str],
    company_supported_languages: List[str],
    default_language: str,
) -> str:
    """
    Decide the language the bot reply should be written in.

    Rules (in order):
      1. Use the detected language if it is explicitly supported.
      2. If the user wrote Hinglish (Roman Hindi) but only ``hindi`` is enabled,
         still answer in Hinglish (Roman mix) so the reply matches how they type.
      3. Fall back to the company's default language.

    Args:
        detected_language:           Language detected in the user message.
        company_supported_languages: Languages the company has enabled.
        default_language:            Company's configured default.

    Returns:
        A language string (``"english"``, ``"hindi"``, ``"hinglish"``).
    """
    supported = company_supported_languages or []
    if detected_language and detected_language in supported:
        return detected_language
    if (
        detected_language == "hinglish"
        and "hinglish" not in supported
        and "hindi" in supported
    ):
        return "hinglish"
    return default_language
