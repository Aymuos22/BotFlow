"""
RAGService – orchestrates retrieval-augmented generation.

Flow
----
1. Resolve company config (Weaviate collection, RAG JSON, prompts).
2. Detect language for retrieval; resolve reply language using conversation
   stickiness when *conversation_reply_language* is provided; optionally merge
   recent conversation into the search query.
3. Normalize query for Weaviate.
4. Optionally embed the query; run hybrid (BM25 + vector) or BM25-only search.
5. Evaluate retrieval confidence (configurable strategy over score list).
6. Re-rank with lexical MMR + deduplicate; label chunks with source filenames.
7. Call LLM with context (and optional conversation transcript).
8. Log retrieval metadata; return answer + sources.

Result dict keys
----------------
- ``response_type``: ``"rag"`` or ``"fallback"``
- ``answer``:        Text to send to the customer
- ``fallback_triggered``: bool
- ``language``:      Output language
- ``sources``:       List of dicts ``file_name``, ``document_id``, ``chunk_index``, ``score``
"""
import asyncio
import json
import logging
import math
import re
import uuid
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from app.integrations.llm.client import LLMClientProtocol
from app.integrations.weaviate.client import WeaviateClient
from app.repositories.company_config_repository import CompanyConfigRepository
from app.services.fallback_service import FallbackService
from app.services.language_service import (
    detect_language,
    normalize_query,
    resolve_reply_language,
)
from app.utils.rag_postprocess import (
    dedupe_chunk_texts,
    format_conversation_transcript,
    format_hit_for_llm,
    merge_query_with_history,
    mmr_lexical_select,
)

if TYPE_CHECKING:
    from app.integrations.embeddings.client import EmbeddingClientProtocol

logger = logging.getLogger(__name__)

_RAW_JSON_MAX_BYTES = 120_000

# Short greetings / chit-chat score poorly in BM25 against product or policy docs;
# we still want a natural LLM reply instead of the low-confidence fallback.
_SMALL_TALK_MAX_CHARS = 96
_SMALL_TALK_MAX_WORDS = 8
_SMALL_TALK_CONTEXT_CHUNK = (
    "[Meta-instruction: The user sent a short greeting or conversational opener, "
    "not a factual question. Reply briefly and warmly as customer support. "
    "Do not say you could not find information in documents. Offer to help with "
    "products, orders, or other questions.]"
)


def _looks_like_greeting_or_small_talk(text: str) -> bool:
    """
    True when the message is only a greeting or brief conversational phrase.

    These queries rarely match indexed chunks with a high retrieval score, but
    the user still expects a normal assistant reply, not the knowledge-base
    fallback message.
    """
    t = (text or "").strip()
    if not t or len(t) > _SMALL_TALK_MAX_CHARS:
        return False
    words = t.split()
    if len(words) > _SMALL_TALK_MAX_WORDS:
        return False
    low = " ".join(t.lower().split())
    if re.fullmatch(r"(thanks?|thank\s+you|thx|ty)\b[!.]*", low):
        return True
    if re.fullmatch(r"(ok+|okay|k)\b[!.]*", low):
        return True
    if re.fullmatch(r"(bye|goodbye|see\s+ya|later)\b[!.]*", low):
        return True
    if re.fullmatch(
        r"(h+e+l+l*o+|h+i+|hey+|hiya|hallo|namaste|namaskar)\s+ji\b[!.]*",
        low,
    ):
        return True
    if re.fullmatch(
        r"(h+e+l+l*o+|h+i+|hey+|hiya|hallo|namaste|namaskar)([!.,\s]*)?$",
        low,
    ):
        return True
    if re.fullmatch(r"good\s+(morning|afternoon|evening|day)\b[!.,\s]*", low):
        return True
    if re.fullmatch(r"नमस्ते|नमस्कार", t.strip()):
        return True
    return False


def _sanitize_for_json(obj: Any) -> Any:
    if isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    if isinstance(obj, dict):
        return {str(k): _sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize_for_json(v) for v in obj]
    return obj


def _clip_raw_result_for_db(raw: Any) -> Any:
    cleaned = _sanitize_for_json(raw)
    try:
        encoded = json.dumps(cleaned, default=str).encode("utf-8")
    except (TypeError, ValueError):
        return {"_error": "raw_result not JSON-serializable"}
    if len(encoded) <= _RAW_JSON_MAX_BYTES:
        return cleaned
    return {
        "_truncated": True,
        "original_bytes": len(encoded),
        "preview": encoded[:8000].decode("utf-8", errors="replace"),
    }


RetrievalLogPersister = Callable[[Dict[str, Any]], Awaitable[None]]


async def _persist_retrieval_log_best_effort(payload: Dict[str, Any]) -> None:
    from app.core.database import AsyncSessionLocal
    from app.repositories.retrieval_log_repository import RetrievalLogRepository

    try:
        async with AsyncSessionLocal() as session:
            repo = RetrievalLogRepository(session)
            try:
                await repo.create(payload)
                await session.commit()
            except Exception:
                await session.rollback()
                logger.warning(
                    "retrieval_logs insert failed (isolated session)",
                    exc_info=True,
                )
    except Exception:
        logger.warning(
            "retrieval_logs could not open/write session",
            exc_info=True,
        )


async def _persist_product_events_best_effort(
    company_id: uuid.UUID,
    product_ids: List[str],
    event_type: str,
    channel: str,
    conversation_id: Optional[uuid.UUID],
    query_text: str,
) -> None:
    """
    Fire product analytics events in an isolated session.
    Non-fatal: any error is logged and swallowed.
    """
    from app.core.database import AsyncSessionLocal
    from app.repositories.product_event_repository import ProductEventRepository

    try:
        async with AsyncSessionLocal() as session:
            repo = ProductEventRepository(session)
            try:
                for pid_str in product_ids:
                    try:
                        pid = uuid.UUID(pid_str)
                    except (ValueError, AttributeError):
                        continue
                    await repo.create_event(
                        company_id=company_id,
                        product_id=pid,
                        event_type=event_type,
                        channel=channel,
                        conversation_id=conversation_id,
                        query_text=query_text[:500] if query_text else None,
                    )
                await session.commit()
            except Exception:
                await session.rollback()
                logger.warning(
                    "product_events insert failed",
                    exc_info=True,
                )
    except Exception:
        logger.warning(
            "product_events could not open session",
            exc_info=True,
        )


def _hits_from_search_result(search_result: Dict[str, Any]) -> List[Dict[str, Any]]:
    hits = search_result.get("hits")
    if hits:
        return list(hits)
    chunks = search_result.get("chunks") or []
    return [
        {
            "chunk_text": c,
            "file_name": "",
            "document_id": None,
            "chunk_index": None,
            "score": None,
        }
        for c in chunks
    ]


def _scores_for_fallback(hits: List[Dict[str, Any]], top_score: Optional[float]) -> List[float]:
    out: List[float] = []
    for h in hits:
        s = h.get("score")
        if s is None:
            continue
        try:
            f = float(s)
        except (TypeError, ValueError):
            continue
        if math.isnan(f) or math.isinf(f):
            continue
        out.append(f)
    if not out and top_score is not None:
        try:
            ts = float(top_score)
            if not math.isnan(ts) and not math.isinf(ts):
                return [ts]
        except (TypeError, ValueError):
            pass
    return out


class RAGService:
    def __init__(
        self,
        config_repo: CompanyConfigRepository,
        weaviate_client: WeaviateClient,
        llm_client: LLMClientProtocol,
        fallback_service: FallbackService,
        default_top_k: int = 5,
        default_score_threshold: float = 0.4,
        default_hybrid_alpha: float = 0.5,
        default_confidence_strategy: str = "top",
        default_avg_top_n: int = 3,
        default_conversation_turns: int = 8,
        augment_search_with_history: bool = True,
        log_persister: Optional[RetrievalLogPersister] = None,
        embedding_client: Optional["EmbeddingClientProtocol"] = None,
    ) -> None:
        self._config_repo = config_repo
        self._weaviate = weaviate_client
        self._llm = llm_client
        self._fallback_svc = fallback_service
        self._default_top_k = default_top_k
        self._default_threshold = default_score_threshold
        self._default_hybrid_alpha = default_hybrid_alpha
        self._default_confidence_strategy = default_confidence_strategy
        self._default_avg_top_n = default_avg_top_n
        self._default_conversation_turns = default_conversation_turns
        self._augment_search = augment_search_with_history
        self._embedding = embedding_client
        self._log_persister: RetrievalLogPersister = (
            log_persister or _persist_retrieval_log_best_effort
        )

    async def process_query(
        self,
        company_id: uuid.UUID,
        query: str,
        conversation_id: Optional[uuid.UUID] = None,
        message_id: Optional[uuid.UUID] = None,
        background_tasks: Any = None,
        *,
        conversation_messages: Optional[List[Any]] = None,
        conversation_transcript: Optional[str] = None,
        conversation_reply_language: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        ``conversation_reply_language`` is the last decisive user language in
        the thread (e.g. WhatsApp ``Conversation.detected_language`` before the
        current message). Short/ambiguous queries keep replying in that language.
        """
        config = await self._config_repo.get_by_company(company_id)
        if config is None:
            logger.warning(
                "No config found for company; using fallback",
                extra={"company_id": str(company_id)},
            )
            return self._fallback_result("No company config found.", "english")

        collection = config.weaviate_collection
        rag_config = config.rag_config_json or {}
        threshold = float(rag_config.get("score_threshold", self._default_threshold))
        top_k = int(rag_config.get("top_k", self._default_top_k))
        hybrid_alpha = float(rag_config.get("hybrid_alpha", self._default_hybrid_alpha))
        confidence_strategy = str(
            rag_config.get("confidence_strategy", self._default_confidence_strategy)
        )
        avg_top_n = int(rag_config.get("confidence_avg_top_n", self._default_avg_top_n))
        use_mmr = bool(rag_config.get("use_mmr", True))
        mmr_lambda = float(rag_config.get("mmr_lambda", 0.55))
        system_prompt = config.system_prompt if hasattr(config, "system_prompt") else None
        fallback_config = config.fallback_config_json
        supported_langs = list(config.supported_languages or ["english"])
        default_lang = config.default_language or "english"

        detected_lang = detect_language(query)
        output_lang = resolve_reply_language(
            current_text=query,
            conversation_last_language=conversation_reply_language,
            company_supported_languages=supported_langs,
            default_language=default_lang,
        )

        history_text = conversation_transcript
        if history_text is None and conversation_messages:
            max_turns = int(
                rag_config.get("conversation_turns", self._default_conversation_turns)
            )
            history_text = format_conversation_transcript(
                conversation_messages,
                max_turns=max_turns,
            )

        augment = self._augment_search and bool(
            rag_config.get("augment_search_with_history", True)
        )
        search_query = query
        if augment and history_text and history_text.strip():
            search_query = merge_query_with_history(query, history_text)

        normalized = normalize_query(search_query, detected_lang)

        query_vector: Optional[List[float]] = None
        embed_enabled = bool(rag_config.get("use_embeddings", True))
        if self._embedding is not None and embed_enabled:
            try:
                query_vector = await self._embedding.embed_query(normalized[:8000])
                if not query_vector:
                    query_vector = None
            except Exception as exc:
                logger.warning(
                    "Query embedding failed; using BM25 only",
                    extra={"company_id": str(company_id), "error": str(exc)},
                )
                query_vector = None

        search_result = await self._weaviate.hybrid_search(
            collection_name=collection,
            query=normalized,
            top_k=top_k,
            query_vector=query_vector,
            hybrid_alpha=hybrid_alpha,
        )

        hits = _hits_from_search_result(search_result)
        top_score: Optional[float] = search_result.get("top_score")
        if top_score is not None and isinstance(top_score, float) and (
            math.isnan(top_score) or math.isinf(top_score)
        ):
            top_score = None
        raw_result = search_result.get("raw", {})
        scores_fb = _scores_for_fallback(hits, top_score)

        use_fallback = self._fallback_svc.should_fallback(
            scores_fb,
            threshold,
            confidence_strategy,
            avg_top_n=avg_top_n,
        )

        selected_hits = hits
        if not use_fallback and use_mmr and len(hits) > 1:
            selected_hits = mmr_lexical_select(
                hits,
                query=query,
                max_chunks=top_k,
                lambda_mult=mmr_lambda,
            )
        elif not use_mmr:
            selected_hits = hits[:top_k]

        chunk_strings = [format_hit_for_llm(h) for h in selected_hits]
        chunk_strings = dedupe_chunk_texts(chunk_strings)

        sources: List[Dict[str, Any]] = []
        seen_k: set[tuple[Any, ...]] = set()
        # Collect unique product_ids from retrieved chunks for analytics
        retrieved_product_ids: List[str] = []
        seen_pids: set[str] = set()
        for h in selected_hits:
            key = (
                h.get("file_name"),
                h.get("document_id"),
                h.get("chunk_index"),
            )
            if key in seen_k:
                continue
            seen_k.add(key)
            sources.append(
                {
                    "file_name": h.get("file_name") or "",
                    "document_id": str(h["document_id"])
                    if h.get("document_id") is not None
                    else None,
                    "chunk_index": h.get("chunk_index"),
                    "score": h.get("score"),
                    "product_id": h.get("product_id"),
                }
            )
            pid = h.get("product_id")
            if pid and str(pid) not in seen_pids:
                seen_pids.add(str(pid))
                retrieved_product_ids.append(str(pid))

        if use_fallback and _looks_like_greeting_or_small_talk(query):
            use_fallback = False
            chunk_strings = [_SMALL_TALK_CONTEXT_CHUNK]
            sources = []
            retrieved_product_ids = []

        llm_failed = False
        if use_fallback:
            answer = self._fallback_svc.get_fallback_message(
                fallback_config, output_lang
            )
            response_type = "fallback"
        else:
            try:
                answer = await self._llm.generate_answer(
                    context_chunks=chunk_strings,
                    user_query=query,
                    system_prompt=system_prompt,
                    output_language=output_lang,
                    conversation_history=history_text,
                )
                response_type = "rag"
            except Exception as exc:
                logger.warning(
                    "LLM generate_answer failed",
                    extra={"company_id": str(company_id), "error": str(exc)},
                    exc_info=True,
                )
                llm_failed = True
                answer = (
                    "I'm having trouble generating a reply right now. "
                    "Please try a shorter question or again in a moment."
                )
                response_type = "fallback"

        fallback_out = use_fallback or llm_failed
        if fallback_out:
            sources = []

        # ── Product analytics events ─────────────────────────────────── #
        if retrieved_product_ids:
            channel = "portal" if conversation_id is None else "whatsapp"
            if background_tasks is not None:
                background_tasks.add_task(
                    _persist_product_events_best_effort,
                    company_id,
                    retrieved_product_ids,
                    "retrieved",
                    channel,
                    conversation_id,
                    query,
                )
                if not fallback_out:
                    background_tasks.add_task(
                        _persist_product_events_best_effort,
                        company_id,
                        retrieved_product_ids,
                        "suggested",
                        channel,
                        conversation_id,
                        query,
                    )
            else:
                asyncio.create_task(
                    _persist_product_events_best_effort(
                        company_id, retrieved_product_ids, "retrieved",
                        channel, conversation_id, query,
                    )
                )
                if not fallback_out:
                    asyncio.create_task(
                        _persist_product_events_best_effort(
                            company_id, retrieved_product_ids, "suggested",
                            channel, conversation_id, query,
                        )
                    )

        log_payload = {
            "company_id": company_id,
            "conversation_id": conversation_id,
            "message_id": message_id,
            "query_text": query,
            "normalized_query": normalized,
            "detected_language": detected_lang,
            "weaviate_collection": collection,
            "top_k": top_k,
            "top_score": top_score,
            "result_count": len(hits),
            "fallback_triggered": fallback_out,
            "handoff_triggered": False,
            "raw_result_json": _clip_raw_result_for_db(
                {
                    "weaviate": raw_result,
                    "search_mode": search_result.get("search_mode"),
                    "scores": scores_fb,
                    "confidence_strategy": confidence_strategy,
                }
            ),
        }
        if background_tasks is not None:
            background_tasks.add_task(self._log_persister, log_payload)
        else:
            asyncio.create_task(self._log_persister(log_payload))

        return {
            "response_type": response_type,
            "answer": answer,
            "fallback_triggered": fallback_out,
            "language": output_lang,
            "detected_language": detected_lang,
            "top_score": top_score,
            "sources": sources,
            "product_ids": retrieved_product_ids,
        }

    def _fallback_result(self, msg: str, language: str) -> Dict[str, Any]:
        return {
            "response_type": "fallback",
            "answer": msg,
            "fallback_triggered": True,
            "language": language,
            "detected_language": language,
            "sources": [],
        }
