"""FastAPI shared dependencies."""
