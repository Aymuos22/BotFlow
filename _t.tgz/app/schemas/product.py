"""
Pydantic schemas for the Product domain.
"""
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


class ProductBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=500, description="Product name")
    sku: Optional[str] = Field(
        default=None, max_length=200, description="Stock-keeping unit (unique per company)"
    )
    category: Optional[str] = Field(default=None, max_length=200)
    description: Optional[str] = Field(
        default=None,
        description="Full product description – this text is embedded for RAG search",
    )
    price_json: Optional[Dict[str, Any]] = Field(
        default=None,
        description='e.g. {"amount": 999, "currency": "INR", "unit": "per month"}',
    )
    attributes_json: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Arbitrary key-value attributes (color, size, warranty…)",
    )
    is_active: bool = Field(default=True)

    @field_validator("name")
    @classmethod
    def strip_name(cls, v: str) -> str:
        return v.strip()


class ProductCreate(ProductBase):
    """Body for POST /companies/{id}/products."""
    pass


class ProductUpdate(BaseModel):
    """Body for PUT /companies/{id}/products/{pid} – all fields optional."""
    name: Optional[str] = Field(default=None, min_length=1, max_length=500)
    sku: Optional[str] = Field(default=None, max_length=200)
    category: Optional[str] = None
    description: Optional[str] = None
    price_json: Optional[Dict[str, Any]] = None
    attributes_json: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class ProductRead(ProductBase):
    """Full product representation returned by read endpoints."""
    id: uuid.UUID
    company_id: uuid.UUID
    weaviate_indexed: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ProductListResponse(BaseModel):
    products: List[ProductRead]
    total: int


# ── Analytics ────────────────────────────────────────────────────────

class ProductAnalyticsItem(BaseModel):
    product_id: str
    name: str
    sku: Optional[str]
    category: Optional[str]
    retrieved_count: int
    suggested_count: int
    unique_conversations: int
    suggestion_rate_pct: float


class ProductAnalyticsResponse(BaseModel):
    period_days: int
    total_events: int
    items: List[ProductAnalyticsItem]
    top_retrieved: List[ProductAnalyticsItem]
    top_suggested: List[ProductAnalyticsItem]


# ── Reindex ──────────────────────────────────────────────────────────

class ReindexResult(BaseModel):
    product_id: str
    name: str
    success: bool
    message: str


class BulkReindexResponse(BaseModel):
    queued: int
    message: str
