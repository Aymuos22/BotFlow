"""Meta WhatsApp Cloud API — send text messages via Graph API."""
from __future__ import annotations

import logging
import re
from typing import Any, Dict
from urllib.parse import quote

import httpx

from app.core.exceptions import ExternalServiceError

logger = logging.getLogger(__name__)


def _to_recipient_digits(to_number: str) -> str:
    s = (to_number or "").strip()
    if s.startswith("whatsapp:"):
        s = s[len("whatsapp:") :].strip()
    s = re.sub(r"\D", "", s.split("@")[0])
    if not s:
        raise ExternalServiceError(
            service="MetaWhatsApp",
            message="Empty or invalid destination phone for Cloud API send.",
        )
    return s


class MetaWhatsAppClient:
    """
    Async client for ``POST /vNN.N/{phone-number-id}/messages``.
    """

    def __init__(
        self,
        *,
        access_token: str,
        phone_number_id: str,
        graph_base_url: str,
        graph_version: str,
        timeout: int = 30,
    ) -> None:
        self.access_token = access_token
        self.phone_number_id = phone_number_id.strip()
        self.timeout = timeout
        base = graph_base_url.rstrip("/")
        ver = graph_version.strip().lstrip("/")
        self._url = f"{base}/{ver}/{quote(self.phone_number_id, safe='')}/messages"

    def _raise_for_status(self, response: httpx.Response, operation: str) -> None:
        if response.is_error:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise ExternalServiceError(
                service="MetaWhatsApp",
                message=f"{operation} failed (HTTP {response.status_code}): {detail}",
            )

    async def send_text(self, to_number: str, text: str) -> Dict[str, Any]:
        to_digits = _to_recipient_digits(to_number)
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_digits,
            "type": "text",
            "text": {"preview_url": False, "body": text},
        }
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                self._url,
                headers=headers,
                json=payload,
            )
        self._raise_for_status(response, "send_text")
        logger.info(
            "Meta WhatsApp message sent",
            extra={"to": to_digits, "url": self._url},
        )
        try:
            return response.json()
        except Exception:
            return {}
