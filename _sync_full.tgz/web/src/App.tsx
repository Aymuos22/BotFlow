import { useEffect, useState } from "react";
import {
  Navigate,
  NavLink,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";
import type { Session, User } from "@supabase/supabase-js";
import { supabase, appRoleFromUser, companyIdFromUser } from "./lib/supabase";
import { PageLoader } from "./components/Spinner";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import CompanySupport from "./pages/CompanySupport";
import CompanyChat from "./pages/CompanyChat";
import CompanyInbox from "./pages/CompanyInbox";
import { ToastProvider, useToast } from "./context/ToastContext";

function roleOrNull(u: User | null): "admin" | "user" | null {
  if (!u) return null;
  return appRoleFromUser(u);
}

function MissingRole() {
  return (
    <div className="auth-page">
      <div className="card" style={{ maxWidth: 520 }}>
        <h2 style={{ marginTop: 0 }}>Role not configured</h2>
        <p className="lead">
          Your account has no <code>app_metadata.role</code> set. Contact an
          administrator to assign <code>admin</code> or <code>user</code>.
        </p>
        <button
          type="button"
          className="secondary"
          onClick={() => supabase.auth.signOut()}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}

function Shell() {
  const toast = useToast();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="app-loading">
        <PageLoader message="Signing you in…" />
      </div>
    );
  }

  const user = session?.user ?? null;
  const role = roleOrNull(user);
  const chatLayout = location.pathname === "/chat" || location.pathname === "/inbox";
  const adminLayout =
    location.pathname === "/admin" ||
    location.pathname.startsWith("/admin/");

  const navLinkClass = ({ isActive }: { isActive: boolean }) =>
    isActive ? "active" : undefined;

  return (
    <>
      <header className="app-header">
        <NavLink to="/" className="app-brand">
          <span className="app-brand-mark" aria-hidden />
          Portal
        </NavLink>
        <nav className="app-nav">
          {session ? (
            <>
              {role === "admin" && (
                <>
                  <NavLink to="/admin" className={navLinkClass}>Companies</NavLink>
                  <NavLink to="/chat" className={navLinkClass}>Assistant</NavLink>
                </>
              )}
              {role === "user" && (
                <>
                  <NavLink to="/chat" className={navLinkClass}>Assistant</NavLink>
                  {companyIdFromUser(user) && (
                    <NavLink to="/inbox" className={navLinkClass}>Inbox</NavLink>
                  )}
                </>
              )}
              <button
                type="button"
                className="secondary"
                onClick={() => {
                  void supabase.auth.signOut().then(() => {
                    toast.info("Signed out.");
                  });
                }}
              >
                Sign out
              </button>
            </>
          ) : (
            <NavLink to="/login" className={navLinkClass}>Sign in</NavLink>
          )}
        </nav>
      </header>

      <main
        className={
          chatLayout && session && role
            ? "main-content main-content--flush"
            : adminLayout && session && role
              ? "main-content main-content--wide"
              : "main-content"
        }
      >
        <div
          className={
            chatLayout && session && role
              ? "main-content__inner main-content__inner--flush"
              : "main-content__inner"
          }
        >
        <Routes>
          <Route
            path="/login"
            element={
              session ? (
                role ? (
                  <Navigate to={role === "admin" ? "/admin" : "/chat"} replace />
                ) : (
                  <MissingRole />
                )
              ) : (
                <Login />
              )
            }
          />
          <Route
            path="/admin"
            element={
              !session ? (
                <Navigate to="/login" replace />
              ) : !role ? (
                <MissingRole />
              ) : role !== "admin" ? (
                <Navigate to="/chat" replace />
              ) : (
                <AdminDashboard accessToken={session.access_token} />
              )
            }
          />
          <Route
            path="/admin/companies/:companyId"
            element={
              !session ? (
                <Navigate to="/login" replace />
              ) : !role ? (
                <MissingRole />
              ) : role !== "admin" ? (
                <Navigate to="/chat" replace />
              ) : (
                <CompanySupport accessToken={session.access_token} />
              )
            }
          />
          <Route
            path="/chat"
            element={
              !session ? (
                <Navigate to="/login" replace />
              ) : !role ? (
                <MissingRole />
              ) : (
                <CompanyChat
                  accessToken={session.access_token}
                  role={role}
                  user={user!}
                />
              )
            }
          />
          <Route
            path="/inbox"
            element={
              !session ? (
                <Navigate to="/login" replace />
              ) : !role ? (
                <MissingRole />
              ) : role === "user" && user && companyIdFromUser(user) ? (
                <CompanyInbox
                  accessToken={session.access_token}
                  companyId={companyIdFromUser(user)!}
                />
              ) : (
                <Navigate to={role === "admin" ? "/admin" : "/chat"} replace />
              )
            }
          />
          <Route
            path="/"
            element={
              <Navigate
                to={
                  !session
                    ? "/login"
                    : role === "admin"
                      ? "/admin"
                      : role === "user"
                        ? "/chat"
                        : "/login"
                }
                replace
              />
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        </div>
      </main>
    </>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  );
}
