import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  getInboxMessages,
  listInboxConversations,
  patchInboxConversation,
  sendInboxMessage,
  type InboxConversation,
  type InboxMessage,
} from "../lib/supportApi";
import ChatMarkdown from "../components/ChatMarkdown";
import { PageLoader, Spinner } from "../components/Spinner";
import { useToast } from "../context/ToastContext";

type Props = {
  accessToken: string;
  companyId: string;
};

function formatTime(iso: string | null | undefined): string {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function warmthLabel(w: string | null | undefined): string {
  if (!w) return "";
  return w.charAt(0).toUpperCase() + w.slice(1);
}

export default function CompanyInbox({ accessToken, companyId }: Props) {
  const toast = useToast();
  const [rows, setRows] = useState<InboxConversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);
  const [inquiryFilter, setInquiryFilter] = useState<"all" | "open" | "complete">(
    "all",
  );
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<InboxMessage[]>([]);
  const [msgLoading, setMsgLoading] = useState(false);
  const [compose, setCompose] = useState("");
  const [sendBusy, setSendBusy] = useState(false);
  const [patchBusy, setPatchBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const threadRef = useRef<HTMLDivElement>(null);
  /** When true, new messages or polling may scroll the thread to the end. */
  const stickToBottomRef = useRef(true);

  const selected = useMemo(
    () => rows.find((r) => r.id === selectedId) ?? null,
    [rows, selectedId],
  );

  const loadList = useCallback(async () => {
    setErr(null);
    try {
      const q =
        inquiryFilter === "all" ? undefined : { inquiry: inquiryFilter };
      const data = await listInboxConversations(accessToken, companyId, q);
      setRows(data);
      setSelectedId((prev) => {
        if (prev && !data.some((d) => d.id === prev)) return data[0]?.id ?? null;
        return prev;
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to load inbox";
      setErr(msg);
    } finally {
      setLoading(false);
    }
  }, [accessToken, companyId, inquiryFilter]);

  const loadMessages = useCallback(
    async (convId: string, opts?: { silent?: boolean }) => {
      const silent = opts?.silent === true;
      if (!silent) setMsgLoading(true);
      try {
        const data = await getInboxMessages(accessToken, companyId, convId);
        setMessages(data);
      } catch (e) {
        if (!silent) {
          toast.error(e instanceof Error ? e.message : "Failed to load messages");
        }
      } finally {
        if (!silent) setMsgLoading(false);
      }
    },
    [accessToken, companyId, toast],
  );

  useEffect(() => {
    void loadList();
  }, [loadList]);

  // Refresh sidebar + active thread in the background (no full-thread spinner, no jumpy scroll).
  useEffect(() => {
    const t = window.setInterval(() => {
      void loadList();
      if (selectedId) void loadMessages(selectedId, { silent: true });
    }, 25_000);
    return () => window.clearInterval(t);
  }, [loadList, loadMessages, selectedId]);

  useEffect(() => {
    if (selectedId) {
      stickToBottomRef.current = true;
      setMessages([]);
      void loadMessages(selectedId, { silent: false });
    } else {
      setMessages([]);
    }
  }, [selectedId, loadMessages]);

  const onThreadScroll = useCallback(() => {
    const el = threadRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
    stickToBottomRef.current = nearBottom;
  }, []);

  useEffect(() => {
    if (!stickToBottomRef.current) return;
    endRef.current?.scrollIntoView({ behavior: "auto" });
  }, [messages]);

  async function onSend(e: FormEvent) {
    e.preventDefault();
    if (!selectedId || !compose.trim() || sendBusy) return;
    setSendBusy(true);
    try {
      await sendInboxMessage(accessToken, companyId, selectedId, compose.trim());
      setCompose("");
      stickToBottomRef.current = true;
      await loadMessages(selectedId, { silent: false });
      await loadList();
      toast.success("Message sent");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Send failed");
    } finally {
      setSendBusy(false);
    }
  }

  async function applyLead(lead: string) {
    if (!selectedId) return;
    const v = lead === "" ? null : lead;
    setPatchBusy(true);
    try {
      const updated = await patchInboxConversation(
        accessToken,
        companyId,
        selectedId,
        { lead_warmth: v },
      );
      setRows((prev) =>
        prev.map((r) => (r.id === updated.id ? { ...r, ...updated } : r)),
      );
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    } finally {
      setPatchBusy(false);
    }
  }

  async function toggleInquiryComplete(next: boolean) {
    if (!selectedId) return;
    setPatchBusy(true);
    try {
      const updated = await patchInboxConversation(
        accessToken,
        companyId,
        selectedId,
        { inquiry_complete: next },
      );
      setRows((prev) =>
        prev.map((r) => (r.id === updated.id ? { ...r, ...updated } : r)),
      );
      toast.success(next ? "Marked inquiry complete" : "Reopened");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed");
    } finally {
      setPatchBusy(false);
    }
  }

  if (loading) {
    return <PageLoader message="Loading conversations…" />;
  }

  return (
    <div className="wa-inbox">
      {err && <p className="error" style={{ margin: "0 0 0.5rem" }}>{err}</p>}

      <div className="wa-inbox__toolbar" style={{ marginBottom: "0.75rem" }}>
        <label className="wa-inbox__filter">
          <span>View</span>
          <select
            value={inquiryFilter}
            onChange={(e) => {
              setInquiryFilter(e.target.value as "all" | "open" | "complete");
              setSelectedId(null);
            }}
          >
            <option value="all">All threads</option>
            <option value="open">Open inquiries</option>
            <option value="complete">Completed inquiries</option>
          </select>
        </label>
        <button
          type="button"
          className="secondary"
          onClick={() => {
            void loadList();
            if (selectedId) {
              stickToBottomRef.current = true;
              void loadMessages(selectedId, { silent: false });
            }
          }}
        >
          Refresh
        </button>
      </div>

      <div className="wa-inbox__panes">
        <aside className="wa-inbox__sidebar">
          {rows.length === 0 && (
            <p style={{ padding: "0.5rem", color: "var(--text-secondary)" }}>
              No conversations yet. Customer WhatsApp messages will show here.
            </p>
          )}
          <ul className="wa-inbox__list">
            {rows.map((r) => (
              <li key={r.id}>
                <button
                  type="button"
                  className={
                    "wa-inbox__row" + (r.id === selectedId ? " wa-inbox__row--active" : "")
                  }
                  onClick={() => setSelectedId(r.id)}
                >
                  <div className="wa-inbox__row-top">
                    <span className="wa-inbox__phone">{r.customer_phone}</span>
                    {r.lead_warmth && (
                      <span className={"wa-badge wa-badge--" + r.lead_warmth}>
                        {warmthLabel(r.lead_warmth)}
                      </span>
                    )}
                    {r.inquiry_complete && (
                      <span className="wa-badge wa-badge--done" title="Inquiry complete">
                        Done
                      </span>
                    )}
                  </div>
                  <div className="wa-inbox__preview">
                    {r.last_message_preview || "—"}
                  </div>
                  <div className="wa-inbox__ts">{formatTime(r.last_message_at)}</div>
                </button>
              </li>
            ))}
          </ul>
        </aside>

        <section className="wa-inbox__main">
          {!selectedId && (
            <div className="wa-inbox__empty">
              <p className="lead">Select a conversation</p>
            </div>
          )}

          {selectedId && selected && (
            <>
              <header className="wa-inbox__header">
                <div>
                  <h2 className="wa-inbox__title">{selected.customer_phone}</h2>
                  <p style={{ margin: "0.15rem 0 0", fontSize: "0.85rem", color: "var(--text-secondary)" }}>
                    Mode: <strong>{selected.current_mode}</strong>
                    {selected.inquiry_complete && selected.inquiry_completed_at && (
                      <>
                        {" · "}
                        Completed {formatTime(selected.inquiry_completed_at)}
                      </>
                    )}
                  </p>
                </div>
                <div className="wa-inbox__actions">
                  <label
                    title={
                      selected.lead_warmth_locked
                        ? "Manual: choose — to clear and let AI update from new messages."
                        : "AI updates from customer messages; choose — to let AI change this again after a manual pick."
                    }
                  >
                    Lead
                    {selected.lead_warmth_locked ? " (manual)" : ""}
                    <select
                      value={selected.lead_warmth ?? ""}
                      disabled={patchBusy}
                      onChange={(e) => void applyLead(e.target.value)}
                    >
                      <option value="">—</option>
                      <option value="hot">Hot</option>
                      <option value="warm">Warm</option>
                      <option value="cold">Cold</option>
                    </select>
                  </label>
                  <label className="wa-inbox__check">
                    <input
                      type="checkbox"
                      checked={selected.inquiry_complete}
                      disabled={patchBusy}
                      onChange={(e) => void toggleInquiryComplete(e.target.checked)}
                    />
                    Inquiry complete
                  </label>
                </div>
              </header>

              <div
                className="wa-inbox__thread"
                ref={threadRef}
                onScroll={onThreadScroll}
              >
                {msgLoading && messages.length === 0 && (
                  <div className="wa-inbox__thread-loading">
                    <Spinner label="Loading messages…" />
                  </div>
                )}
                {!msgLoading || messages.length > 0
                  ? messages.map((m) => {
                    const out =
                      m.sender_type === "customer" ? false : true;
                    return (
                      <div
                        key={m.id}
                        className={
                          "wa-bubble" + (out ? " wa-bubble--out" : " wa-bubble--in")
                        }
                      >
                        <div className="wa-bubble__meta">
                          {m.sender_type}
                          {m.response_type && (
                            <span style={{ color: "var(--text-muted)" }}> · {m.response_type}</span>
                          )}
                          <span style={{ color: "var(--text-muted)" }}>
                            {" "}
                            · {formatTime(m.created_at)}
                          </span>
                        </div>
                        <div className="wa-bubble__body">
                          {m.sender_type === "bot" ? (
                            <ChatMarkdown text={m.message_text} />
                          ) : (
                            <p style={{ margin: 0, whiteSpace: "pre-wrap" }}>{m.message_text}</p>
                          )}
                        </div>
                      </div>
                    );
                  })
                  : null}
                <div ref={endRef} />
              </div>

              <form className="wa-inbox__compose" onSubmit={onSend}>
                <textarea
                  rows={2}
                  placeholder="Type a WhatsApp message to the customer…"
                  value={compose}
                  onChange={(e) => setCompose(e.target.value)}
                  disabled={sendBusy}
                />
                <button type="submit" className="primary" disabled={sendBusy || !compose.trim()}>
                  {sendBusy ? "Sending…" : "Send"}
                </button>
              </form>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
