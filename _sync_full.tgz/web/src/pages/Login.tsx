import { FormEvent, useState } from "react";
import { supabase } from "../lib/supabase";
import { useToast } from "../context/ToastContext";

export default function Login() {
  const toast = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      const msg =
        error.status === 400 || error.message.toLowerCase().includes("invalid")
          ? "Incorrect email or password. Please try again."
          : error.message;
      setErr(msg);
      toast.error(msg);
    } else {
      toast.success("Signed in.");
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card stack">
        <div>
          <h1>Welcome back</h1>
          <p className="lead">Sign in to continue.</p>
        </div>
        <form className="stack" onSubmit={onSubmit}>
          <label>
            <span>Email</span>
            <input
              type="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@example.com"
            />
          </label>
          <label>
            <span>Password</span>
            <input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
            />
          </label>
          {err && <p className="error">{err}</p>}
          <button className="primary" type="submit" disabled={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
