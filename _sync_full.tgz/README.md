# MindoraxAI – Multi-Tenant WhatsApp RAG SaaS Backend

A production-grade, multi-tenant **WhatsApp chatbot backend** powered by
Retrieval-Augmented Generation (RAG). Companies onboard, upload their knowledge
base, and immediately get an AI-powered WhatsApp assistant that answers
customer queries in English, Hindi, or Hinglish – with full human-handoff
escalation and analytics.

---

python scripts/ec2_setup.py --deploy-only

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│  WhatsApp (via Twilio)                                      │
│  POST /api/v1/webhooks/twilio/messages  ◄────────────────── │
└─────────────────────────────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│  FastAPI Application (app.main)                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │ Correlation-ID Middleware  (every request gets UUID) │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌──────────────────┐  ┌──────────────────────────────┐    │
│  │  API v1 Routers  │  │  Pydantic Schemas (request/  │    │
│  │  (thin, no biz)  │  │   response validation)       │    │
│  └──────────────────┘  └──────────────────────────────┘    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Services (business logic)                           │   │
│  │  OnboardingService │ RAGService │ HandoffService     │   │
│  │  DocumentService   │ IndexingService                 │   │
│  │  ConversationService │ AnalyticsService              │   │
│  │  LanguageService  │ FallbackService │ MetricsAggr.  │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Repositories (SQLAlchemy 2.0 Async)                 │   │
│  │  CompanyRepo │ ConversationRepo │ HandoffRepo        │   │
│  │  DocumentRepo │ MessageRepo │ AnalyticsRepo          │   │
│  │  DailyMetricsRepo │ RetrievalLogRepo                 │   │
│  └──────────────────────────────────────────────────────┘   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Integrations (all mockable)                         │   │
│  │  TwilioClient │  WeaviateClient  │  S3StorageClient   │   │
│  │  GroqLLMClient (default) │ OpenAILLMClient            │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
           │                    │                    │
           ▼                    ▼                    ▼
   Supabase / SQLite        Weaviate              AWS S3
   (relational data)      (vector store)       (document files)
```

### Key Design Principles

- **Multi-tenant, config-driven**: Every company has its own `CompanyConfig`
  row. Onboarding a new company requires zero code changes or redeployment.
- **Redeploy-free runtime config**: All AI behaviour, fallback messages, handoff
  thresholds, and language settings are stored in the database.
- **Clean Architecture**: Routers → Services → Repositories → Integrations.
  No business logic in route handlers.
- **All external services mockable**: `TwilioClient`, `WeaviateClient`,
  `S3StorageClient`, and `LLMClientProtocol` are injected via FastAPI DI,
  making unit and API tests fast and deterministic.
- **No Redis**: All state (jobs, conversations, handoffs, metrics) is in the
  relational database.

---

## Module Overview

| Module | Purpose |
|--------|---------|
| `app/models/` | SQLAlchemy ORM models (all 10 tables) |
| `app/schemas/` | Pydantic request/response schemas |
| `app/repositories/` | Async DB access layer (one class per model) |
| `app/services/` | Business logic (orchestration, rules) |
| `app/api/v1/endpoints/` | FastAPI routers (thin – delegate to services) |
| `app/integrations/` | Twilio, Weaviate, S3, LLM clients |
| `app/utils/` | Text processing, S3 keys, language helpers, correlation ID |
| `app/core/` | Config, database, exceptions, logging, response schemas |

---

## Database Tables

| Table | Phase | Description |
|-------|-------|-------------|
| `companies` | 1 | Company master record |
| `company_configs` | 1 | Per-company runtime config (JSON columns) |
| `company_channels` | 1 | WhatsApp channel registration |
| `onboarding_statuses` | 1 | Onboarding progress checklist |
| `documents` | 2 | Document metadata (file is in S3) |
| `document_index_jobs` | 2 | DB-backed indexing job queue |
| `conversations` | 2 | Customer conversation threads |
| `messages` | 2 | Individual messages (customer / bot / agent) |
| `retrieval_logs` | 2 | Immutable RAG retrieval audit log |
| `handoffs` | 3 | Human escalation events |
| `daily_company_metrics` | 3 | Pre-aggregated daily analytics |

---

## API Overview

All routes are under `/api/v1`.

### Phase 1 – Onboarding & company management
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/onboarding/company/full` | Full company onboarding |
| `GET` | `/companies/{id}/readiness` | Onboarding readiness |
| `POST` | `/companies/{id}/activate` | Activate company (Twilio + Weaviate gates) |
| `GET` / `PUT` | `/companies/{id}/config` | Read / update prompts, languages, RAG JSON, `is_active` — **does not** accept Twilio credentials (see Portal row below) |

### Phase 2 – Document Management
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/companies/{id}/documents/upload` | Upload document (stores to S3, triggers indexing) |
| `GET` | `/companies/{id}/documents` | List documents |
| `GET` | `/companies/{id}/documents/{doc_id}` | Get document metadata |
| `POST` | `/companies/{id}/documents/{doc_id}/index` | Re-trigger indexing |

### Phase 2 – Webhook
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/webhooks/twilio/messages` | Receive Twilio WhatsApp webhooks (TwiML ack; replies via Twilio API) |

### Phase 3 – Human Handoff
| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/conversations/{id}/handoff` | Request handoff |
| `GET` | `/companies/{id}/handoffs` | List company handoffs |
| `POST` | `/handoffs/{id}/assign` | Assign agent to handoff |
| `POST` | `/handoffs/{id}/resolve` | Resolve handoff |
| `POST` | `/conversations/{id}/resume-bot` | Resume bot mode |

### Phase 3 – Agent Messaging
| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/agents/{agent_id}/conversations` | Agent's active conversations |
| `POST` | `/conversations/{id}/messages/agent` | Agent sends a message |

### Phase 3 – Analytics
| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/companies/{id}/analytics/overview` | Aggregate KPIs |
| `GET` | `/companies/{id}/analytics/languages` | Language usage breakdown |
| `GET` | `/companies/{id}/analytics/fallbacks` | Fallback analysis |
| `GET` | `/companies/{id}/analytics/handoffs` | Handoff metrics |
| `GET` | `/companies/{id}/analytics/top-queries` | Top customer queries |

All analytics endpoints accept `?period_days=N` (default 30, max 365).

### Portal API

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/portal/chat` | Stateless RAG Q&A; `Authorization: Bearer` (legacy portal token or **Supabase** JWT when `SUPABASE_JWT_SECRET` is set), or `X-Portal-Company-Key` when `PORTAL_COMPANY_KEYS_JSON` is set |
| `GET` | `/portal/admin/companies` | List companies; same Bearer rules, or `X-Admin-Key` when `PORTAL_ADMIN_API_KEY` is set |
| `GET` | `/portal/companies/{id}/config/overview` | One payload for the dashboard; `integration` includes `twilio_credentials_complete`, `has_twilio_auth_token`, `twilio_account_sid`, and `twilio_credentials_save_path` so the UI can warn when replies will fail |
| `POST` | `/portal/admin/companies/{id}/twilio` | Save Twilio **WhatsApp number**, **Account SID**, and **Auth Token** (admin key or admin Bearer). **First** save must include `twilio_auth_token`; later saves may omit it to keep the stored token while changing SID or number |

When `PORTAL_ADMIN_API_KEY` is set, `POST /onboarding/company/full` also requires `X-Admin-Key` **unless** the Bearer token is already an **admin** (portal or Supabase).

If `PORTAL_COMPANY_KEYS_JSON` and `PORTAL_ADMIN_API_KEY` are **unset**, portal chat and onboarding stay open for local development (not for production).

### Supabase Auth roles (web app)

The React UI in `web/` uses Supabase Auth. The API validates access tokens when `SUPABASE_JWT_SECRET` matches your Supabase project’s **JWT secret** (Dashboard → Project Settings → API).

Set **Custom user metadata** / **`app_metadata`** per user (SQL editor or Admin API):

- **Admin:** `{"role": "admin"}`
- **Tenant user:** `{"role": "user", "company_id": "<uuid>"}` — use the company id returned after onboarding.

### React web app (`web/`)

```bash
cd web
cp .env.example .env
# VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, VITE_API_BASE_URL (backend)
# Twilio: call POST /api/v1/portal/admin/companies/{id}/twilio (not PUT .../config).
# Use GET .../portal/companies/{id}/config/overview → integration.twilio_credentials_complete

npm install
npm run dev
```

Open http://localhost:5173 — admins see onboarding + company list; users see RAG chat for their `company_id`.

---

## Local Setup

### Prerequisites

- Python 3.10+
- A Supabase project (PostgreSQL)
- A Weaviate instance (local or cloud)
- Twilio WhatsApp configured (sandbox or business sender); credentials stored per company
- AWS S3 bucket (or use LocalStack for local dev)
- OpenAI API key

### 1. Clone and install

```bash
git clone https://github.com/your-org/mindorax-backend
cd mindorax-backend
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
```

### 2. Configure environment variables

```bash
cp .env.example .env
# Edit .env with your actual values
```

### 3. Run database migrations

> Phase 4 will add Alembic migrations.  For now, tables are created via
> SQLAlchemy's `create_all` on startup (development only).

For production, run the following once:

```python
# scripts/create_tables.py
import asyncio
from app.core.database import engine
from app.models.base import Base
import app.models  # ensure all models are imported

async def main():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

asyncio.run(main())
```

### 4. Start the server

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Visit http://localhost:8000/docs for the interactive API documentation.

---

## Running Tests

```bash
# All tests
python -m pytest app/tests/ -v

# With coverage
python -m pytest app/tests/ --cov=app --cov-report=term-missing

# Unit tests only
python -m pytest app/tests/unit/ -v

# API tests only
python -m pytest app/tests/ -m api -v

# Single test file
python -m pytest app/tests/test_e2e.py -v
```

**Requirements for tests**: All external services (Twilio HTTP, Weaviate, S3, LLM)
are mocked. No real AWS, Weaviate, Groq, or OpenAI credentials are needed.

---

## Environment Variables

### Core

| Variable | Default | Description |
|----------|---------|-------------|
| `APP_ENV` | `development` | `development` \| `production` |
| `APP_NAME` | `MindoraxAI` | Application name (shown in docs) |
| `APP_VERSION` | `0.1.0` | API version |
| `DATABASE_URL` | — | PostgreSQL async URL (`postgresql+asyncpg://...`) |
| `DEBUG` | `false` | Show detailed error messages in responses |
| `LOG_LEVEL` | `INFO` | Python logging level |
| `SECRET_KEY` | — | **Required in production** – random 32+ char string |

### Weaviate

| Variable | Description |
|----------|-------------|
| `WEAVIATE_URL` | Weaviate URL (e.g. `http://localhost:8080`) |
| `WEAVIATE_API_KEY` | Weaviate API key (if using Weaviate Cloud) |

### AWS S3

| Variable | Description |
|----------|-------------|
| `AWS_ACCESS_KEY_ID` | AWS Access Key (omit when using EC2 IAM role) |
| `AWS_SECRET_ACCESS_KEY` | AWS Secret Key (omit when using EC2 IAM role) |
| `AWS_REGION` | AWS region (e.g. `us-east-1`) |
| `S3_BUCKET_NAME` | S3 bucket name for document storage |
| `AWS_ENDPOINT_URL` | Override endpoint (for LocalStack / moto local dev) |

### LLM (Groq default, or OpenAI)

| Variable | Description |
|----------|-------------|
| `LLM_PROVIDER` | `groq` (default) or `openai` |
| `GROQ_API_KEY` | Groq API key (from [console.groq.com](https://console.groq.com)) |
| `OPENAI_API_KEY` | Used only when `LLM_PROVIDER=openai` |
| `LLM_MODEL` | e.g. `openai/gpt-oss-120b` (Groq) or `gpt-4o-mini` (OpenAI) |
| `LLM_TIMEOUT_SECONDS` | Not passed to Groq SDK directly; OpenAI client uses it |
| `LLM_TEMPERATURE` | Groq: default `1` |
| `LLM_MAX_COMPLETION_TOKENS` | Groq: default `8192` |
| `LLM_TOP_P` | Groq: default `1` |
| `LLM_REASONING_EFFORT` | Groq reasoning models: `low` \| `medium` \| `high` |
| `LLM_STREAM` | `true` to use streaming and aggregate chunks (Groq) |

### RAG & Indexing

| Variable | Default | Description |
|----------|---------|-------------|
| `RAG_SCORE_THRESHOLD` | `0.4` | Minimum Weaviate score to trust |
| `RAG_TOP_K` | `5` | Max chunks to retrieve |
| `CHUNK_SIZE` | `1000` | Characters per text chunk |
| `CHUNK_OVERLAP` | `100` | Character overlap between chunks |
| `INDEXING_MAX_RETRIES` | `3` | Max indexing job retries |

---

## AWS S3 Configuration

### Bucket Setup

1. Create an S3 bucket (e.g. `mindorax-documents-prod`).
2. **Block all public access** – documents are only accessed via signed URLs.
3. Enable **server-side encryption** (SSE-S3 or SSE-KMS).
4. Set a lifecycle policy to transition old documents to Glacier after 90 days
   (optional).

### Object Key Naming Strategy

All document files follow the pattern:

```
companies/{company_id}/documents/{document_id}/{sanitized_filename}
```

Example:

```
companies/abc123.../documents/def456.../product_catalog.pdf
```

This ensures:
- Strict tenant isolation (company_id as prefix)
- Easy deletion of all company data via `delete_prefix`
- No collisions between tenants

### IAM Permissions

Minimum required policy for the application role/user:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject",
        "s3:HeadObject"
      ],
      "Resource": "arn:aws:s3:::mindorax-documents-prod/*"
    },
    {
      "Effect": "Allow",
      "Action": ["s3:ListBucket"],
      "Resource": "arn:aws:s3:::mindorax-documents-prod"
    }
  ]
}
```

### Production (EC2 IAM Role)

On EC2, attach an IAM role with the policy above.  **Do not set
`AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY`** – boto3 automatically
discovers credentials from the EC2 instance metadata service.

```bash
# .env on EC2 (omit static keys)
S3_BUCKET_NAME=mindorax-documents-prod
AWS_REGION=us-east-1
# AWS_ACCESS_KEY_ID=  ← DO NOT SET
# AWS_SECRET_ACCESS_KEY=  ← DO NOT SET
```

### Local Development

For local development, you can use:
1. **Real AWS credentials** – set `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`
2. **LocalStack** – set `AWS_ENDPOINT_URL=http://localhost:4566`
3. **moto** (tests only) – the test suite uses moto automatically, no
   real S3 credentials needed

---

## Human Handoff Flow

### Trigger Conditions

1. **Keyword-triggered**: Customer message contains a human-request phrase
   (e.g. "talk to human", "agent please", "mujhe agent chahiye").
2. **Low-confidence-triggered**: RAG score is below
   `low_confidence_handoff_threshold` AND `handoff_on_low_confidence: true`
   is set in the company's `handoff_config_json`.

### Configuration

Set in `company_configs.handoff_config_json`:

```json
{
  "handoff_on_low_confidence": true,
  "low_confidence_handoff_threshold": 0.3,
  "human_request_keywords": ["my custom phrase"],
  "handoff_acknowledgement": {
    "english": "Connecting you to an agent. Please wait.",
    "hindi": "एजेंट से जोड़ रहे हैं, कृपया प्रतीक्षा करें।",
    "hinglish": "Agent se connect kar rahe hain. Wait karein."
  }
}
```

### Staff WhatsApp alert (optional)

Set `handoff_staff_notify_whatsapp` on `company_configs` to `whatsapp:+E164` (via `PUT /api/v1/companies/{id}/config`). On each **new** handoff (not when an active handoff already exists), the API sends that number a short WhatsApp message using the company’s stored Twilio sender and credentials. If Twilio is incomplete or the send fails, the handoff is still created; errors are logged only.

### State Transitions

```
bot mode  →  [handoff triggered]  →  agent mode
                                          │
                              [agent resolves handoff]
                                          │
                              conversation stays in agent mode
                                          │
                              [operator calls resume-bot API]
                                          │
                                       bot mode
```

**Note**: Resolving a handoff does NOT automatically resume the bot.
This is intentional – the agent may want to send a closing message before
handing back. Call `POST /conversations/{id}/resume-bot` explicitly.

---

## Known Limitations

1. **No JWT authentication**: All API endpoints are currently unauthenticated.
   TODO hooks and role notes are in the code. Add JWT middleware (e.g.
   `python-jose`) and protect routes with `Depends(get_current_user)`.

2. **Synchronous indexing**: `IndexingService.trigger_indexing` runs
   synchronously in the request. For large documents this will block the
   request. Phase 4 should add a background worker polling
   `DocumentIndexJobRepository.list_pending()`.

3. **BM25 keyword search only**: Weaviate is used with BM25 keyword search.
   Vector/embedding search is not yet enabled. Phase 4 will add
   `text2vec-openai` or a custom embedding step.

4. **No conversation history in LLM context**: The LLM receives only the
   current query and retrieved chunks, not the conversation history.
   Phase 4 will pass the last N messages to enable multi-turn coherence.

5. **No rate limiting**: The webhook endpoint has no rate limiting.
   Phase 4 should add `slowapi` or nginx-level rate limiting.

6. **No Alembic migrations**: Tables are created via `create_all`.
   Phase 4 will add `alembic revision --autogenerate` against Postgres.

7. **Business hours not enforced**: The `business_hours_json` column exists
   but is not yet checked before responding. Phase 4 will add out-of-hours
   handling.

8. **Daily metrics not auto-aggregated**: `MetricsAggregationService` must
   be called manually or via a cron job. Phase 4 will add a scheduled task.

---

## Future Improvements (Phase 4+)

- Alembic migrations against live Postgres
- JWT/API key authentication with role-based access control
- Background worker for async document indexing
- Embedding-based vector search (text2vec-openai)
- Conversation history context in LLM prompts
- Business hours enforcement
- Rate limiting on webhook endpoint
- Agent notification system (push/email when handoff is requested)
- Webhook retry handling with exponential backoff
- Multi-language document parsing (language-aware chunking)
- Admin dashboard API for agent management
