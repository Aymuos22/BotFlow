# FAQ — General


---

**Q:** Is this product original / genuine?

**A:** Yes, products ordered from skinrange.com or our official WhatsApp channel are genuine. We always advise purchasing from official, trusted sources.

---

**Q:** Are there fake products in the market?

**A:** Copies of popular products sometimes appear in the market. Buying from official channels is the safest option.

---

**Q:** Is this product safe?

**A:** Ayurvedic herbal products are generally well-tolerated. However, consult a doctor before use if you have chronic conditions, are pregnant, or take regular medication.

---

**Q:** Is there a guarantee on results?

**A:** Health product results depend on individual body response, so no guaranteed results can be promised. Regular use and a healthy lifestyle improve the likelihood of improvement.

---

**Q:** What if the product doesn't suit me?

**A:** Stop using it and contact support. Our team will advise next steps.

---

**Q:** Can teenagers use these products?

**A:** Age suitability depends on the product. Most SKinRange products are for adults (18+). Check the specific product's safety notes or contact support.

---

**Q:** Is there a discount available?

**A:** Yes! Prepaid orders receive 10% discount + a free gift worth Rs. 1,299. Seasonal and combo offers may also be available — contact support or check the website.

---

**Q:** Is COD (Cash on Delivery) available?

**A:** Yes, COD is available on selected products and pin codes. Share your pin code to confirm.

---

**Q:** Is this Ayurvedic or Homeopathic?

**A:** SKinRange products are Ayurvedic — made from natural herbal formulations.

---

**Q:** Is the product GMP and ISO certified?

**A:** Yes. SKinRange's products are manufactured under GMP & ISO certified standards.