# FAQ — Orders & Shipping


---

**Q:** How do I place an order?

**A:** You can order via skinrange.com or by sharing your details on WhatsApp. The team will assist you.

---

**Q:** How will I know my order is confirmed?

**A:** You receive a WhatsApp confirmation message with your Order ID and amount paid.

---

**Q:** How long does delivery take?

**A:** 4–7 working days from order confirmation, depending on your location.

---

**Q:** Is shipping free?

**A:** Yes. Free shipping across India on all orders.

---

**Q:** What if no one is available for delivery?

**A:** The courier leaves a missed-delivery card and makes a second attempt within 48 hours. You can share your contact number for the courier to call before delivery.

---

**Q:** Can I cancel my order?

**A:** Yes, before shipment. Once shipped, the order follows the return policy.

---

**Q:** How do I track my order?

**A:** A tracking link is shared in the WhatsApp order confirmation message.

---

**Q:** Is prepaid payment mandatory?

**A:** No. COD is available. But prepaid orders get 10% off + free gift worth Rs. 1,299.

---

**Q:** Mera order kab tak ayega? (When will my order arrive?)

**A:** Order dispatch ke baad delivery usually 4–7 working days mein ho jati hai. Agar aap apni order details share kar dein to hum aapki behtar madad kar sakte hain.