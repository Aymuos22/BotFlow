# FAQ — Account & Support


---

**Q:** Can I speak to a doctor?

**A:** Yes. SKinRange offers free in-house Ayurvedic doctor consultations. Contact support to schedule a call.

---

**Q:** Can I get a callback?

**A:** Yes. Share your number and preferred time. The support team will connect you.

---

**Q:** Can you send me the usage guide?

**A:** Yes. The support agent or chatbot will share the usage routine and instructions for your specific product.

---

**Q:** What if I have more questions?

**A:** Message us on WhatsApp anytime. Our team is here to help.

---

**Q:** Can I ask the same question again?

**A:** Yes, aap kabhi bhi apna sawal yahan bhej sakte hain. Hum aapki help ke liye yahin hain.

---

**Q:** Doctor se baat ho sakti hai kya?

**A:** Ji haan, agar zaroorat ho to hum aapki doctor consultation arrange karne mein help kar sakte hain.